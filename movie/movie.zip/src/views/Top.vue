<template>
    <div>
        <h1 style="text-align: left">豆瓣电影排行榜</h1>
        <h2 style="color:green; text-align: left">豆瓣新片榜……</h2>
        <el-divider></el-divider>

        <el-row  v-for="grade in synopsis">
            <el-col span="4">
                <img src="../assets/1.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left;">
                <a href="#"style="text-decoration:none;"><h6>小丑 / 小丑起源电影：罗密欧 / Romeo</h6></a>
            </el-col>
            <el-col :span="14" style="text-align: left;">
                <p style="font-size: 10px;">电影《小丑》以同名DC漫画角色为基础，由华纳兄弟影业公司发行，计划于2019年10月4日上映。本片的故事将独立于DCEU之外，
                    故事背景设置在20世纪80年代，讲述了一位生活陷入困境的脱口秀喜剧演员渐渐走向精神的崩溃，在哥谭市开始了疯狂的犯罪生
                    涯，最终成为了蝙蝠侠的宿敌“小丑”的故事。本片由《宿醉》的导演托德菲利普斯执导，他与编剧斯科特西尔弗一起撰写了编
                    剧。杰昆菲尼克斯本片中饰演主人公“小丑”，其他的主演包括罗伯特德尼罗、莎姬贝兹、马克马龙等。
                </p>
                <el-rate
                        v-model="value1"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/2.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>爱尔兰人 / 爱尔兰杀手(港) / 听说你刷房子了</h6></a>
                <p style="font-size: 10px">《爱尔兰人》为马丁·斯科塞斯执导的传奇巨制，罗伯特·德尼罗、阿尔·帕西诺和乔·佩西主演。通过二战老兵弗兰克·希兰的视角，
                    讲述了战后美国有组织犯罪的故事。弗兰克·希兰是一名骗子和杀手，曾经在 20 世纪最恶名昭彰的人物身边工作。该电影跨越数十年，
                    记录了美国历史上最大的悬案之一，即传奇工会领袖吉米·霍法失踪案，以宏大的故事之旅，展现有组织犯罪的隐秘通道：其内部运作、
                    仇敌以及与主流政治的瓜葛。
                </p>
                <div>
                <el-rate
                        v-model="value2"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
                </div>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/3.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>82年生的金智英 / 82年生金智英 / Kim Ji-young,Born 1982</h6></a>
                <p style="font-size: 10px">　同名小说改编而成，直击韩国家庭和社会上的性别不公议题。金智英（郑有美 饰）一直按照社会规范下的女性身份生活，成
                    为重男轻女的父母所期待的「好女儿」，职场上温顺隐忍的「好女人」，和以家庭为重的「好妻子」。直到一天她好似被附身
                    一样，言行如同自己的母亲一般，丈夫（孔侑 饰）决定带她接受心理咨询，两个人一同重新面对她的人生伤痛。小说面世以来
                    饱受争议，甚至在电影改编计划期间出现全国性的请愿反对，这段「不可言说」的故事面对社会压力仍被搬上银幕，值得关注
                    。</p>
                <el-rate
                        v-model="value3"
                         disabled
                         show-score
                         text-color="#ff9900"
                         score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/4.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>好莱坞往事 / 从前，有个荷里活(港) / 从前，有个好莱坞...(台) </h6></a>
                <p style="font-size: 10px">故事在1969年瞬息万变的洛杉矶展开，在那个风起云涌的变革时代，嬉皮文化盛行，好莱坞大制片厂制度瓦解，新的好莱坞明星纷
                    纷崛起。电视明星里克·道尔顿（莱昂纳多·迪卡普里奥 Leonardo DiCaprio饰）与他长期合作替身搭档克里夫·布斯（布拉德·皮
                    特 Brad Pitt 饰）如何在逐渐陌生的娱乐圈里，找到自己的一席之地。他们正力图扬名电影圈，却发现这个行业早已不是他们想象
                    的样子了…… 这是昆汀自编自导第9部影片，汇集星光闪闪的卡司与交错的情节，纪念好莱坞不再复返的黄金年代。
                </p>
                <el-rate
                        v-model="value4"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">

                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/5.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>婚姻故事 </h6></a>
                <p style="font-size: 10px">以一起离婚事件探讨婚姻和爱情，诺亚·鲍姆巴赫执导， 亚当·德赖弗扮演一个剧作家，斯嘉丽·约翰逊扮演一个女明星，两人因各自工
                    作分居纽约和洛杉矶而不得不走向离婚，主演另有劳拉·邓恩、格蕾塔·葛韦格。 Netflix参与制作。 。
                </p>
                <el-rate
                        v-model="value5"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/6.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>准备好了没 / 弑婚游戏(台) / 爆血新婚夜(港) </h6></a>
                <p style="font-size: 10px">讲述19岁单纯姑娘佩内洛普即将嫁入豪门，婚礼当天晚上，丈夫查理古怪的家族成员邀请她参与一项历史悠久的传
                    统，结果演变成一个离奇恐怖的致命游戏，引发灾难。
                </p>
                <el-rate
                        v-model="value6"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/7.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>克劳斯：圣诞节的秘密 / 圣诞老人 </h6></a>
                <p style="font-size: 10px">贾斯帕（詹森·舒瓦兹曼饰）被认为是邮政学院最差的学生，他驻扎在北极圈内的一个冰冻岛屿上，那里的当地人之间几乎
                    不交流，更不用说写信了。当贾斯帕准备放弃之时，他找到了自己的盟友阿尔娃（当地的一名教师，拉什达·琼斯饰），并
                    发现了克劳斯（奥斯卡奖得主 J·K·西蒙斯饰），克劳斯是一个神秘的木匠，独自住在一个满是手工玩具的小屋里。这几段
                    不可思议的友谊让斯密伦斯堡又重新充满了欢声笑语，创造出了新的故事，这里有慷慨的邻居、神奇的传说和小心翼翼挂在
                    烟囱上的长袜。《克劳斯：圣诞节的秘密》是一部节日喜剧动画片，由《神偷奶爸》联合创剧人塞尔希奥·巴勃罗斯担任导
                    演，由琼·库萨克、威尔·萨索和诺曼·麦克唐纳徳联袂主演。
                </p>
                <el-rate
                        v-model="value7"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col span="4">
                <img src="../assets/8.jpg" style="width: 150px;height:200px">
            </el-col>
            <el-col :span="14" style="text-align: left">
                <a href="#" style="text-decoration:none"><h6>第一滴血5：最后的血 / 第一滴血：终极血战(港) / 蓝波：最后一滴血(台) </h6></a>
                <p style="font-size: 10px">西尔维斯特·史泰龙回归[第一滴血5]，并有望执导。除主演外，据悉史泰龙将操刀剧本，故事围绕兰博为营救朋友之女与
                    墨西哥毒枭展开殊死搏斗展开。制片艾威·勒纳([敢死队]系列)。该系列首部于1982年上映，2008年史泰龙曾自导自演[第
                    一滴血4]。[第一滴血5]将在本届戛纳电影节预售，9月开拍。
                </p>
                <el-rate
                        v-model="value8"
                        disabled
                        show-score
                        text-color="#ff9900"
                        score-template="{value}">
                </el-rate>
            </el-col>
        </el-row>
    </div>
</template>
<script>
    import ElProgress from "../../node_modules/element-ui/packages/progress/src/progress";
    export default {
        data() {
            return {
                synopsis:[
                    {score:3.7},
                    {score:3.7},
                    {score:3.7},
                    {score:3.7},
                    {score:3.7},
                    {score:3.7},
                    {score:3.7},
                    {score:3.7}
                ]
//                value1:3.7,
//                value2:4.7,
//                value3:3.7,
//                value4:3.7,
//                value5:3.7,
//                value6:3.7,
//                value7:3.7,
//                value8:3.7,
                   }
            }
    }
</script>
